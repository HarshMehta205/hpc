#include<iostream>
#include<fstream>
#include<stdlib.h>
#include <stdio.h>
#include<omp.h>
#include<string.h>
#include<math.h>
#include<cstdlib>
#include<string.h>

using namespace std;

//OpenMP is a library for parallel programming in the SMP (symmetric multi-processors, or shared-memory processors) model. When programming with OpenMP, all threads share memory and data.

/*The time.h header file contains definitions of functions to get and manipulate date and time information. 

    The omp_get_wtime function returns elapsed wall-clock time.
    The omp_get_wtick function returns seconds between successive clock ticks.
*/



/* THEORY ABOUT OPENMP -
When run, an OpenMP program will use one thread (in the sequential sections), and several threads (in the parallel sections).

There is one thread that runs from the beginning to the end, and it's called the master thread. The parallel sections of the program will cause additional threads to fork. These are called the slave threads.

A section of code that is to be executed in parallel is marked by a special directive (omp pragma). When the execution reaches a parallel section (marked by omp pragma), this directive will cause slave threads to form. Each thread executes the parallel section of the code independently. When a thread finishes, it joins the master. When all threads finish, the master continues with code following the parallel section.

Each thread has an ID attached to it that can be obtained using a runtime library function (called omp_get_thread_num()). The ID of the master thread is 0.

Why OpenMP? More efficient, and lower-level parallel code is possible, however OpenMP hides the low-level details and allows the programmer to describe the parallel code with high-level constructs, which is as simple as it can get. */


//----------------------------------------------------------------------------------------------------------------------------

/*
In OpenMP, we need to mention the region which we are going to make it as parallel using the keyword pragma omp parallel. The pragma omp parallel is used to fork additional threads to carry out the work enclosed in the parallel. The original thread will be denoted as the master thread with thread ID 0. Code for creating a parallel region would be,

#pragma omp parallel
{
  //Parallel region code 
} 
*/


/*
#pragma omp parallel num_threads(4) -> method to create n no. of threads
*/


/*
In a parallel section variables can be private or shared:

    private: the variable is private to each thread, which means each thread will have its own local copy. A private variable is not initialized and the value is not maintained for use outside the parallel region. By default, the loop iteration counters in the OpenMP loop constructs are private.
    shared: the variable is shared, which means it is visible to and accessible by all threads simultaneously. By default, all variables in the work sharing region are shared except the loop iteration counter. Shared variables must be used with care because they cause race conditions. 
    firstprivate (variable list) -Private variables are initialized to variable value before the parallel directive


The type of the variable, private or shared, is specified following the #pragma omp: 
*/


/*
OpenMP lets you control how the threads are scheduled. The type of schedule available are:

    static: Each thread is assigned a chunk of iterations in fixed fashion (round robin). The iterations are divided among threads equally. Specifying an integer for the parameter chunk will allocate chunk number of contiguous iterations to a particular thread. Note: is this the default? check.

    dynamic: Each thread is initialized with a chunk of threads, then as each thread completes its iterations, it gets assigned the next set of iterations. The parameter chunk defines the number of contiguous iterations that are allocated to a thread at a time.

    guided: Iterations are divided into pieces that successively decrease exponentially, with chunk being the smallest size. 

This is specified by appending schedule(type, chunk) after the pragma for directive:

#pragma omp for schedule(static, 5)
*/



/*
A process is an instance of a computer program that
is being executed. It contains the program code and
its current activity.
• A thread of execution is the smallest unit of
processing that can be scheduled by an operating
system.
• Differences between threads and processes:
– A thread is contained inside a process. Multiple threads
can exist within the same process and share resources
such as memory. The threads of a process share the
latter’s instructions (code) and its context (values that
its variables reference at any given moment).
*/

/*
“Pragma”: stands for “pragmatic information.
A pragma is a way to communicate the
information to the compiler.
*/
//----------------------------------------------------------------------------------------------------------------------------



void insertintofile1(int n,int arr[])                                       //function for inserting numbers into file 1
{
ofstream out;
out.open("new1.txt",ios::out);
if(out.is_open())
	{
               for(int i=0;i<n;i++)
             {
               out<<arr[i]<<endl;
	      
             }
 out.close();
        }

}
void insertintofile2(int n,int arr[])                                 //function for inserting numbers in file 2
{ 
ofstream out;
out.open("new2.txt",ios::out);
if(out.is_open())
	{
               for(int i=0;i<n;i++)
             {
             
                   out<<arr[i]<<endl;
             }
        }
        out.close();

}

void add(int arr1[],int arr2[],int n1,int n2)                            //function for adding numbers from two files.
{
fstream out ,out1 ,out2;
int arr3[10000];
out2.open("output.txt",ios::out);                                           //open output file
out.open("new1.txt",ios::in);                                               //open first input file
out1.open("new2.txt",ios::in);                                              //open second input file
int sum=0;
int i=0,j=0,k=0;
if(out.is_open() && out1.is_open())
{

 while(i<n1||j<n2)
{

  out>>arr1[i];
  out1>>arr2[j];
cout<<"arr1 "<<arr1[i]<<"\n";
cout<<"arr2 "<<arr2[j]<<"\n";
  arr3[k]=arr1[i]+arr2[j];
cout<<"Answer : arr3 "<<arr3[k]<<"\n";                                                           //write the result of addition into the third file.
   
  out2<<arr3[k];
  out2<<endl;
 i++,j++,k++;
  
}

}

}

void addparallel(int arr1[],int arr2[],int n1,int n2)                               //function to parallely fetch numbers from files and add.
{
fstream out ,out1 ,out2;
int arr3[10000];
out2.open("output2.txt",ios::out);
out.open("new1.txt",ios::in);
out1.open("new2.txt",ios::in);
int sum=0;
int i=0,j=0,k=0;
if(out.is_open() && out1.is_open())
{

#pragma omp parallel	 					       
while(i<n1 ||j<n2) 
{
out>>arr1[i];
out1>>arr2[j];


cout<<"arr1 "<<arr1[i]<<"\n";
cout<<"arr2 "<<arr2[j]<<"\n";

i++,j++ ;
}

i=0,j=0,k=0;
while(k<n1 ||k<n2)
{
           arr3[k]=arr1[i]+arr2[j];
        
           out2<<arr3[k]<<endl;
           i++,j++,k++;
   

}




}

 
}
int main()
{


int arr1[10000],arr2[10000];
int n1 ,n2;
cout<<"\nEnter the count of numbers in first file\n";
cin>>n1;
cout<<"\n Enter the numbers\n";
for(int i=0;i<n1;i++)
{
 arr1[i]=rand()%n1;
//cin>>arr1[i];

}
insertintofile1(n1,arr1);
cout<<"\nEnter the count of numbers in second  file\n";
cin>>n2;
cout<<"\n Enter the numbers\n";
double ts,tp;
for(int i=0;i<n2;i++)
{
 arr2[i]=rand()%n2;
//cin>>arr2[i];


}
insertintofile2(n2,arr2);

//double start,end;
// start=omp_get_wtime();
add(arr1,arr2,n1,n2);
// end=omp_get_wtime();
//cout<<"\n Time in sequential is "<<end-start;
//ts=end-start;
 //start=omp_get_wtime();
addparallel(arr1,arr2,n1,n2);
//end=omp_get_wtime();
//tp=end-start;
//cout<<"\n Time in parallel is "<<end-start;

//cout<<"\n Speed up "<<ts/tp;






}

/* COMMMAND TO RUN OPENMP FILE - 
1)gcc filename.c -o filename.out
	OR
 gcc -fopenmp filename -o filename.out
2)./filename.out
*/
