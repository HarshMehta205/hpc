#include<stdio.h>
#include<omp.h>
#include<stdlib.h>
#include<time.h>

//OpenMP is a library for parallel programming in the SMP (symmetric multi-processors, or shared-memory processors) model. When programming with OpenMP, all threads share memory and data.

/*The time.h header file contains definitions of functions to get and manipulate date and time information. 

    The omp_get_wtime function returns elapsed wall-clock time.
    The omp_get_wtick function returns seconds between successive clock ticks.
*/




/* THEORY ABOUT OPENMP -
When run, an OpenMP program will use one thread (in the sequential sections), and several threads (in the parallel sections).

There is one thread that runs from the beginning to the end, and it's called the master thread. The parallel sections of the program will cause additional threads to fork. These are called the slave threads.

A section of code that is to be executed in parallel is marked by a special directive (omp pragma). When the execution reaches a parallel section (marked by omp pragma), this directive will cause slave threads to form. Each thread executes the parallel section of the code independently. When a thread finishes, it joins the master. When all threads finish, the master continues with code following the parallel section.

Each thread has an ID attached to it that can be obtained using a runtime library function (called omp_get_thread_num()). The ID of the master thread is 0.

Why OpenMP? More efficient, and lower-level parallel code is possible, however OpenMP hides the low-level details and allows the programmer to describe the parallel code with high-level constructs, which is as simple as it can get. */


//----------------------------------------------------------------------------------------------------------------------------

/*
In OpenMP, we need to mention the region which we are going to make it as parallel using the keyword pragma omp parallel. The pragma omp parallel is used to fork additional threads to carry out the work enclosed in the parallel. The original thread will be denoted as the master thread with thread ID 0. Code for creating a parallel region would be,

#pragma omp parallel
{
  //Parallel region code 
} 
*/


/*
#pragma omp parallel num_threads(4) -> method to create n no. of threads
*/



/*
In a parallel section variables can be private or shared:

    private: the variable is private to each thread, which means each thread will have its own local copy. A private variable is not initialized and the value is not maintained for use outside the parallel region. By default, the loop iteration counters in the OpenMP loop constructs are private.
    shared: the variable is shared, which means it is visible to and accessible by all threads simultaneously. By default, all variables in the work sharing region are shared except the loop iteration counter. Shared variables must be used with care because they cause race conditions. 
    firstprivate (variable list) -Private variables are initialized to variable value before the parallel directive

The type of the variable, private or shared, is specified following the #pragma omp: 
*/


/*
OpenMP lets you control how the threads are scheduled. The type of schedule available are:

    static: Each thread is assigned a chunk of iterations in fixed fashion (round robin). The iterations are divided among threads equally. Specifying an integer for the parameter chunk will allocate chunk number of contiguous iterations to a particular thread. Note: is this the default? check.

    dynamic: Each thread is initialized with a chunk of threads, then as each thread completes its iterations, it gets assigned the next set of iterations. The parameter chunk defines the number of contiguous iterations that are allocated to a thread at a time.

    guided: Iterations are divided into pieces that successively decrease exponentially, with chunk being the smallest size. 

This is specified by appending schedule(type, chunk) after the pragma for directive:

#pragma omp for schedule(static, 5)
*/


/*
A process is an instance of a computer program that
is being executed. It contains the program code and
its current activity.
• A thread of execution is the smallest unit of
processing that can be scheduled by an operating
system.
• Differences between threads and processes:
– A thread is contained inside a process. Multiple threads
can exist within the same process and share resources
such as memory. The threads of a process share the
latter’s instructions (code) and its context (values that
its variables reference at any given moment).
*/

/*
“Pragma”: stands for “pragmatic information.
A pragma is a way to communicate the
information to the compiler.
*/
//----------------------------------------------------------------------------------------------------------------------------


/* NOTE for BUBBLE SORT -
Odd-Even Transposition Sort is based on the Bubble Sort technique. It compares two adjacent numbers and switches them, if the first number is greater than the second number to get an ascending order list. The opposite case applies for a descending order series. Odd-Even transposition sort operates in two phases − odd phase and even phase. In both the phases, processes exchange numbers with their adjacent number in the right.

hence in traditional bubble sort hum first element se start karte hai aur uske side wale element se compare karte hai aur end tak jaate hai,second se start karte ahi aur end tak jaate hai and son on
in parallel bubble sort hum odd iteration mein hum sirf odd index wale element lete hai aur ushe uske next element se compare karte hai
*/

/*
time complexity - O((n/p)log(n/p) +     O(n)            + O(n)
                   local sorting    communication        comparsion
*/

int main(){
	int n;
	printf("enter array size:- ");
	scanf("%d", &n);
	int arr[n];
	int i;
	int e=1;
	double str = omp_get_wtime();
	for(int i=0; i<n; i++)
	{
		scanf("%d",&arr[i] );
	}

	/*for(i=0;i<((n+1)/2);i++)
	{
		int j;
		#pragma omp parallel for
		for(j=0;j<n;j+=2)
		{
			if(arr[j]>arr[j+1])
			{
				int temp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = temp;
			}

		}

		#pragma omp parallel for
		for(j=1;j<n-1;j+=2)
		{
			int temp1;
			if(arr[j]>arr[j+1])
			{
				temp1 = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = temp1;
			}
		}
	}
*/

int s=0;
int temp;
while(e || s)
{
	e=0;					// we are taking an extra variable "e" because we want to keep the while loop as long as sorting is taking place
		          //suppose if we donot keep "e" then s would become 0 in the first iteration itself and while loop while terminate
			
	#pragma omp parallel for private(temp)    //for -> specify a for loop to be parallelized; no curly braces
							       //pragma omp parallel -> for starting parallel exceution
							       //private(temp) -> a private variable is created
	for(i=s;i<n-1;i=i+2)                  // || means "or," which means "as long as one side of this is true, then the expression is true." 
	
	{
		if(arr[i]>arr[i+1])
		{
			temp = arr[i];
			arr[i] = arr[i+1];
			arr[i+1] = temp;
			e=1;
		}
	}
		if(s==0)
		s=1;
		else
		s=0;

}


	for(int i=0;i<n;i++)
	{
		printf("%d\t", arr[i]);
	}
	printf("\n");
	printf("\nTime of Execution: %lf", omp_get_wtime()-str);
	return 0;
}


/* COMMMAND TO RUN OPENMP FILE - 
1)gcc filename.c -o filename.out
	OR
 gcc -fopenmp filename -o filename.out
2)./filename.out
*/
